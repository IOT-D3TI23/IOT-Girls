import cv2
import numpy as np
from flask import Flask, render_template, Response

app = Flask(__name__)

# Fungsi untuk menghasilkan stream video dari IP Webcam
def gen():
    # Ganti dengan IP HP Anda yang menampilkan stream video
    cap = cv2.VideoCapture("http://192.168.102.220:8080/video")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Proses frame untuk deteksi warna
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Rentang warna untuk deteksi (contoh: deteksi warna hijau)
        # Anda bisa mengubah rentang warna ini sesuai kebutuhan
        lower_color = np.array([35, 100, 100])  # Rentang bawah (warna hijau)
        upper_color = np.array([85, 255, 255])  # Rentang atas (warna hijau)

        # Buat masker untuk rentang warna tertentu
        mask = cv2.inRange(hsv, lower_color, upper_color)
        color_pixels = cv2.countNonZero(mask)

        # Menampilkan teks jika warna terdeteksi
        if color_pixels > 1000:  # Threshold deteksi warna
            cv2.putText(frame, "Color Detected", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)

        # Encode frame sebagai JPEG untuk dikirim ke browser
        ret, jpeg = cv2.imencode('.jpg', frame)
        if not ret:
            break

        # Kirimkan frame sebagai JPEG ke browser melalui Flask
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + jpeg.tobytes() + b'\r\n\r\n')

@app.route('/')
def index():
    # Tampilkan halaman utama untuk streaming video
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    # Mengirimkan stream video ke browser
    return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
